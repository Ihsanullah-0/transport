
package myprojects.final_project;

/**
 *
 * @author IHSANULLAH PC
 */

import java.sql.*;

public class Final_Project {
    public static void main(String[] args) {
        // Replace with your database credentials
        String jdbcURL = "jdbc:mysql://localhost:3306/final_project";
        String dbUser = "root";
        String dbPassword = "";
        
        // SQL query to create the table
        String createTableSQL = "CREATE TABLE IF NOT EXISTS transport_booking (" +
                "id INT AUTO_INCREMENT PRIMARY KEY," +
                "firstname VARCHAR(50) NOT NULL," +
                "lastname VARCHAR(50) NOT NULL," +
                "telephone INT NOT NULL," +
                "email VARCHAR(100) NULL," +
                "from_location VARCHAR(100) NOT NULL," +
                "to_location VARCHAR(100) NOT NULL," +
                "car_name VARCHAR(50) NOT NULL," +
                "seat_no INT NOT NULL," +
                "price INT NOT NULL," +
                "time_submitted TIMESTAMP DEFAULT CURRENT_TIMESTAMP);"; // New time_submitted column

        try (Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
             Statement statement = connection.createStatement()) {

            // Execute the SQL query
            statement.execute(createTableSQL);
            System.out.println("Table 'transport_booking' has been created successfully.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
