package myprojects.final_project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class login {
    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/final_project";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    public static void main(String[] args) {
        // Create a new frame
        JFrame frame = new JFrame("Login Form");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set the layout for the frame (can be anything, but let's use BorderLayout)
        frame.setLayout(new BorderLayout());

        // Set a background image on the frame
        JPanel backgroundPanel = new JPanel() {
            // Override the paintComponent method to draw the background image
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                try {
                    // Set the correct path to your image
                    ImageIcon backgroundImage = new ImageIcon("C:/Users/user/Documents/NetBeansProjects/Final_Project/src/main/resources/images/background.jpg"); // Update path
                    Image img = backgroundImage.getImage();
                    g.drawImage(img, 0, 0, getWidth(), getHeight(), this); // Resize the image to fit the panel
                } catch (Exception e) {
                    System.out.println("Image not found.");
                }
            }
        };

        // Set the background panel size to match the frame size
        backgroundPanel.setPreferredSize(new Dimension(500, 400));
        frame.add(backgroundPanel, BorderLayout.CENTER); // Add the background panel

        // Create a panel for the login form
        JPanel panel = new JPanel();
        
        // Increase opacity by using a Color with a higher alpha value (e.g., 180 instead of 150)
        panel.setBackground(new Color(30, 35, 55, 180)); // Semi-transparent background for the login panel
        panel.setPreferredSize(new Dimension(300, 300)); // Fixed size for the login form
        panel.setLayout(null); // Use null layout for precise component positioning

        // Center the login form panel within the background panel
        backgroundPanel.setLayout(new GridBagLayout());  // Using GridBagLayout to center the panel
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        backgroundPanel.add(panel, gbc); // Add the login form to the center of the background panel

        // Add "Login Form" label
        JLabel titleLabel = new JLabel("Login Form");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(85, 20, 150, 30);
        panel.add(titleLabel);

        // Username label and text field
        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        usernameLabel.setForeground(Color.WHITE);
        usernameLabel.setBounds(30, 70, 100, 20);
        panel.add(usernameLabel);

        JTextField usernameField = new JTextField();
        usernameField.setBounds(30, 90, 220, 30);
        panel.add(usernameField);

        // Password label and password field
        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        passwordLabel.setForeground(Color.WHITE);
        passwordLabel.setBounds(30, 130, 100, 20);
        panel.add(passwordLabel);

        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(30, 150, 220, 30);
        panel.add(passwordField);

        // Login button
        JButton loginButton = new JButton("Login");
        loginButton.setBounds(30, 200, 220, 40);
        loginButton.setBackground(new Color(34, 210, 176));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFont(new Font("Arial", Font.BOLD, 14));
        loginButton.setBorder(null);
        panel.add(loginButton);

        // Make frame visible
        frame.setVisible(true);

        // Add action listener for the login button
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                if (validateUser(username, password)) {
                    JOptionPane.showMessageDialog(frame, "Login successful!");
                    frame.dispose();  // Close the login frame

                    // Show the home form
                    Home homeForm = new Home();  // Create an instance of your existing HomeForm
                    homeForm.setVisible(true);  // Make it visible
                } else {
                    JOptionPane.showMessageDialog(frame, "Invalid username or password.", "Error", JOptionPane.ERROR_MESSAGE);
                    clearForm(usernameField, passwordField);  // Clear the form after failed login attempt
                }
            }
        });
    }

    // Method to validate user credentials
    public static boolean validateUser(String username, String password) {
        String query = "SELECT * FROM login WHERE email = ? AND password = ?";

        try (
            // Establish connection to the database
            Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            // Prepare the SQL statement
            PreparedStatement statement = connection.prepareStatement(query)
        ) {
            // Set the username and password parameters
            statement.setString(1, username);
            statement.setString(2, password);

            // Execute the query and get the result
            try (ResultSet resultSet = statement.executeQuery()) {
                // Return true if the result set contains any rows (i.e., credentials match)
                return resultSet.next();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to clear the form fields (username and password)
    public static void clearForm(JTextField usernameField, JPasswordField passwordField) {
        usernameField.setText("");   // Clear the username field
        passwordField.setText("");   // Clear the password field
    }
}
