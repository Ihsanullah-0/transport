
package myprojects.final_project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class log_in {
    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/final_project";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    public static void main(String[] args) {
        // SQL statement to create the "login" table
        String createTableSQL = "CREATE TABLE IF NOT EXISTS login ("  // Added IF NOT EXISTS
                + "id INT AUTO_INCREMENT PRIMARY KEY, "
                + "email VARCHAR(255) NOT NULL UNIQUE, "
                + "password VARCHAR(255) NOT NULL);";

        // SQL statement to insert values into the "login" table
        String insertValuesSQL = "INSERT INTO login (email, password) VALUES "
                + "('OMEGARWANDA', 'OmegaTransport@2024');";

        try (
            // Establish connection to the database
            Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            // Create a Statement object
            Statement statement = connection.createStatement()
        ) {
            // Create the table if it doesn't exist
            statement.executeUpdate(createTableSQL);
            System.out.println("Table 'login' created successfully!");

            // Insert values into the table
            int rowsInserted = statement.executeUpdate(insertValuesSQL);
            if (rowsInserted > 0) {
                System.out.println("Values inserted successfully!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
