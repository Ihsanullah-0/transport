
package myprojects.final_project;

import java.sql.*;

public class Delivery {
    
    public static void main(String[] args) {
        // Replace with your database credentials
        String jdbcURL = "jdbc:mysql://localhost:3306/final_project";
        String dbUser = "root";
        String dbPassword = "";
        
        // SQL query to create the table
        String createTableSQL = "CREATE TABLE IF NOT EXISTS Delivery (" +
                "id INT AUTO_INCREMENT PRIMARY KEY," +
                "sender_name VARCHAR(50) NOT NULL," +
                "receiver_name VARCHAR(50) NOT NULL," +
                "sender_ID INT NOT NULL," +
                "receiver_ID INT NOT NULL," +
                "sender_telephone INT NOT NULL," +
                "receiver_telephone INT NOT NULL," +
                "From_location VARCHAR(100) NOT NULL," +
                "To_location VARCHAR(100) NOT NULL," +            
                "material_type VARCHAR(50) NOT NULL," +
                "Cost INT NOT NULL," +
                "car_model VARCHAR(50) NOT NULL," +
                "time_submitted TIMESTAMP DEFAULT CURRENT_TIMESTAMP);"; // New time_submitted column

        try (Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
             Statement statement = connection.createStatement()) {

            // Execute the SQL query
            statement.execute(createTableSQL);
            System.out.println("Table 'Delivery' has been created successfully.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
